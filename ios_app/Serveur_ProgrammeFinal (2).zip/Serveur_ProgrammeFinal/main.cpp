#include <iostream>
#include <String.h>
#include <string>
#include <windows.h>
#include <irrKlang/irrKlang.h>
#include <rapidjson/document.h>
#include <rapidjson/writer.h>
#include <rapidjson/stringbuffer.h>
#include "global.hpp"
#include <stdio.h>
#include <MYSQL/mysql.h>
#include <ctype.h>
#include <time.h>
#include <vector>
#include <fstream>

using namespace std;
using namespace irrklang;
using namespace rapidjson;

int valPlayerMode;
int valAction;
int valIdmusic;
int valIdmusicplaying;
int valEmplacement;
float valvolume;
std::vector<string> listeLecture;

void PlayMusic(MYSQL *connexion, ISoundEngine* engine, int idMusic);
void PauseMusic(ISoundEngine* engine);
void RelanceMusic(ISoundEngine* engine);
void ChangeVolumeRate(ISoundEngine* engine, double volumeRate);
string GetFileName(MYSQL *connexion, int idMUSIC);
void EcrireLogErreur(string logAEcrire);
std::vector<string> StockageTableauPistes(MYSQL *connexion, int emplacement);
void PlayNextMusic(MYSQL *connexion, ISoundEngine* engine);
void PlayAvantMusic(MYSQL *connexion, ISoundEngine* engine);
void sendJSONCallBack();

int main(int argc, char* argv[])
{
    MYSQL *mysqlConnexion ; //Variables utiles
    string Message_Recu;

    mysqlConnexion = mysql_init(NULL) ;

    if(!mysql_real_connect(mysqlConnexion, SERVEUR, UTILISATEUR, MOT_DE_PASSE , BDD_AUDIO, 0, NULL, 0))
    {
        EcrireLogErreur("Connexion impossible") ;
    }

    Document d;
    ISoundEngine* engine = NULL;

    engine = createIrrKlangDevice();
    if (engine != NULL)
    {
        cout << "Creation engine irrklang" << endl;
    }

	while(std::getline(std::cin, Message_Recu))
	{
        if (!d.Parse<0>(Message_Recu.c_str()).HasParseError())
        {
            valPlayerMode   = d["player_mode"].GetInt();
            valAction       = d["action"].GetInt();
            valIdmusic      = d["id_music"].GetInt();
            valEmplacement  = d["emplacement"].GetInt();
            valvolume       = d["volume_rate"].GetDouble();

            ChangeVolumeRate(engine, valvolume);

            if(valAction == ACTION_START_MUSIC) {
                PlayMusic(mysqlConnexion, engine, valIdmusic);
            }
            else if(valAction == ACTION_PAUSE_MUSIC) {
                PauseMusic(engine);
            }
            else if(valAction == ACTION_RELAUNCH_MUSIC) {
                RelanceMusic(engine);
            }
            else if(valAction == ACTION_NEXT_MUSIC) {
                // Fct next music
                PlayNextMusic(mysqlConnexion, engine);
            }
            else if(valAction == ACTION_FORWARD_MUSIC){
                // Fct forward music
                PlayAvantMusic(mysqlConnexion, engine);
            }

            sendJSONCallBack();
        }
	}

	engine->drop();

    return 0;
}

void PlayMusic(MYSQL *connexion, ISoundEngine* engine, int idMusic)
{
    engine->stopAllSounds();
    listeLecture                        = StockageTableauPistes(connexion, 0);
    string musique                      = GetFileName(connexion, idMusic);
    string emplacementMusique           = FLAC_PATH + musique;
    const char *emplacement             = emplacementMusique.c_str();
    engine->play2D(emplacement);
    valIdmusicplaying = idMusic;
}

void PauseMusic(ISoundEngine* engine)
{
    engine->setAllSoundsPaused(true);
}

void RelanceMusic(ISoundEngine* engine)
{
    engine->setAllSoundsPaused(false);
}

void ChangeVolumeRate(ISoundEngine* engine, double volumeRate)
{
    engine->setSoundVolume((float)volumeRate);
}

void PlayNextMusic(MYSQL *connexion, ISoundEngine* engine)
{
    int sizeTab = listeLecture.size();
    for(int i = 0; i < sizeTab; i+=2)
    {
        int idMusic = atoi(listeLecture[i].c_str());
        if((idMusic == valIdmusic))
        {
            PlayMusic(connexion, engine, atoi(listeLecture[i+2].c_str()));
        }
    }
}

void PlayAvantMusic(MYSQL *connexion, ISoundEngine* engine)
{
    int sizeTab = listeLecture.size();
    for(int i = 0; i < listeLecture.size(); i+=2)
    {
        int idMusic = atoi(listeLecture[i].c_str());
        if((idMusic == valIdmusic))
        {
            PlayMusic(connexion, engine, atoi(listeLecture[i-2].c_str()));
        }
    }
}

string GetFileName(MYSQL *connexion, int idMUSIC)
{
    string requeteSql;
    string filename = "";
    MYSQL_ROW champsBDD;
    MYSQL_RES *resultatCommandeSql ;
    char castIntString[5] ;
    string idMusic = (string)itoa(idMUSIC, castIntString, 10);
    requeteSql = "SELECT filename FROM pistes WHERE pistes.idPISTES=" + idMusic + " LIMIT 1;";
    int testEnvoiRequete = mysql_query(connexion, requeteSql.c_str()) ;

    if(testEnvoiRequete != 0)
    {
        EcrireLogErreur("Requete recuperation nom fichier flac impossible") ;
    }
    else
    {
        resultatCommandeSql = mysql_store_result(connexion) ; //on recupere la reponse donc l'id
        champsBDD = mysql_fetch_row(resultatCommandeSql) ;

        if(champsBDD)
            filename = champsBDD[0];
        else
            EcrireLogErreur("Recuperation du champ filename impossible") ;
    }

    return filename;
}

void sendJSONCallBack()
{
    cout << "{\"player_mode\": " << valPlayerMode << ", \"id_music\": " << valIdmusic << ", \"id_music_played\": " << valIdmusicplaying << " \"action\": " << valAction << ", \"volume_rate\": "<< valvolume <<",\"emplacement\": " << valEmplacement << "}" << endl;
}

void EcrireLogErreur(string logAEcrire)
{
    time_t maintenant ; //variables utiles
	struct tm *dateInfo ;
	char formatDate[32] ;
	ofstream fichierLog ;
	string cheminComplet ;

    time(&maintenant) ; //initialistation pour la date
    dateInfo = localtime(&maintenant) ;
    strftime(formatDate, 32, "%d/%m/%Y %H:%M:%S", dateInfo); //stockage du format de date souhaite dans le tableau, ici par exemple : 16/04/2016 17:56:52

    cheminComplet = (string)CHEMIN_LOG +"error.log" ; //on rempli le chemin d'acces du fichier � ouvrir

    fichierLog.open (cheminComplet.c_str(), ios::app);  // on ouvre le fichier en ecriture, app pour 'append' pour ajouter � la suite

    if(fichierLog)  // si l'ouverture a r�ussi
    {
        fichierLog << "[" << formatDate << "]" << "   [Player]   " << logAEcrire << "\"" << endl ; //on �crit � la suite

        fichierLog.close();  // on ferme le fichier
    }
    else
    {
        //cout << "Impossible d'ouvrir le fichier log !" << endl ;
    }
}

std::vector<string> StockageTableauPistes(MYSQL *connexion, int emplacement)
{
    //TableauAsso listeLecture ;
    std::vector<string> listeLecture;
    string commandeSQL;
    MYSQL_ROW champsBDD;
    MYSQL_RES *resultatCommandeSql ;

    if(emplacement == EMPLACEMENT_PISTES)
    {
        commandeSQL = "SELECT idPISTES,filename FROM pistes ORDER BY title;";
    }
    else if(emplacement == EMPLACEMENT_ALBUM)
    {

    }
    else
    {

    }

    int testEnvoiRequete = mysql_query(connexion, commandeSQL.c_str()) ;

    if(testEnvoiRequete != 0)
    {
        EcrireLogErreur("Requete recuperation id musics impossible") ;
    }
    else
    {
        resultatCommandeSql = mysql_store_result(connexion) ; //on recupere la reponse donc l'id

        while(champsBDD = mysql_fetch_row(resultatCommandeSql))
        {
            listeLecture.push_back(champsBDD[0]);
            listeLecture.push_back(champsBDD[1]);
        }
    }

    return listeLecture;
}
