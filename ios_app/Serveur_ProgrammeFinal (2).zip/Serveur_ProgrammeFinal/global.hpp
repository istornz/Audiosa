#ifndef GLOBAL_HPP_INCLUDED
#define GLOBAL_HPP_INCLUDED

#define SERVEUR "raspberrypi.home"
#define UTILISATEUR "db_reader_music"
#define MOT_DE_PASSE "qsZuJe6hruAm9nBs"
#define BDD_AUDIO "audio_db"

#define NO_ACTION NULL
#define ACTION_START_MUSIC      0
#define ACTION_PAUSE_MUSIC      1
#define ACTION_RELAUNCH_MUSIC   2
#define ACTION_NEXT_MUSIC       3
#define ACTION_FORWARD_MUSIC    4

#define MODE_REPEAT 0
#define MODE_ALEAT  1

#define EMPLACEMENT_PISTES      0
#define EMPLACEMENT_ALBUM       1
#define EMPLACEMENT_PLAYLIST    2

#define CHEMIN_LOG "C:\\Users\\Dimitri\\Desktop\\Serveur_ProgrammeFinal\\"
#define FLAC_PATH "F:\\Documents\\Audiosa\\Deplacement_FLAC\\"

#endif // GLOBAL_HPP_INCLUDED
