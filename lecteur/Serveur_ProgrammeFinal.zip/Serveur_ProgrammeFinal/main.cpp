#include <iostream>
#include <String.h>
#include <windows.h>
#include <irrKlang/irrKlang.h>
#include <rapidjson/document.h>
#include <rapidjson/writer.h>
#include <rapidjson/stringbuffer.h>
#include "global.hpp"
#include <stdio.h>

using namespace std;
using namespace irrklang;
using namespace rapidjson;

void PlayMusic(ISoundEngine* engine, int idMusic)
{
    engine->stopAllSounds();
    string musique;
    if(idMusic == 10)
    {
        musique = "112-nekfeu-ma_dope_feat_spri_noir.flac";
    }
    else
    {
        musique = "115-nekfeu-princesse_feat_nemi.flac";
    }

    string emplacementMusique = FLAC_PATH + musique;
    const char *emplacement = emplacementMusique.c_str();

    engine->play2D(emplacement);
}
void PauseMusic(ISoundEngine* engine)
{
    engine->setAllSoundsPaused(true);
}

void RelanceMusic(ISoundEngine* engine)
{
    engine->setAllSoundsPaused(false);
}

void ChangeVolumeRate(ISoundEngine* engine, double volumeRate)
{
    engine->setSoundVolume((float)volumeRate);
}

int main(int argc, char* argv[])
{
    string Message_Recu;

    int valAction;
    int valIdmusic = 0;
    float valvolume = 0.5;
    Document d;
    ISoundEngine* engine = NULL;

    engine = createIrrKlangDevice();
    if (engine != NULL)
    {
        cout << "Creation engine irrklang" << endl;
    }

	while(std::getline(std::cin, Message_Recu))
	{
        if (!d.Parse<0>(Message_Recu.c_str()).HasParseError())
        {
            valAction   = d["action"].GetInt();
            valIdmusic  = d["id_music"].GetInt();
            valvolume   = d["volume_rate"].GetDouble();

            ChangeVolumeRate(engine, valvolume);

            if(valAction == ACTION_START_MUSIC) {
                PlayMusic(engine, valIdmusic);
            }
            else if(valAction == ACTION_PAUSE_MUSIC) {
                PauseMusic(engine);
            }
            else if(valAction == ACTION_RELAUNCH_MUSIC) {
                RelanceMusic(engine);
            }
            else if(valAction == ACTION_NEXT_MUSIC) {
                // Fct next music
                PlayMusic(engine, valIdmusic);
            }
            else if(valAction == ACTION_FORWARD_MUSIC){
                // Fct forward music
            }
        }
	}

	engine->drop();

    return 0;
}
